const STORAGE_KEY = "thakirati_ai_notes_v1";
const $ = (id) => document.getElementById(id);
let notes = loadNotes();

function loadNotes(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}
function persist(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(notes)); renderNotes(); }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function renderNotes(){
  $("count").textContent = `${notes.length} معلومة`;
  const term = $("filter").value.trim().toLowerCase();
  const filtered = notes.filter(n => `${n.title} ${n.text} ${n.category}`.toLowerCase().includes(term));
  $("notesList").innerHTML = filtered.map(n => `
    <article class="note">
      <h3>${escapeHtml(n.title)}</h3>
      <p>${escapeHtml(n.text)}</p>
      <div class="note-bottom"><span>${escapeHtml(n.category)} · ${new Date(n.createdAt).toLocaleDateString("ar-IQ")}</span>
      <button class="delete" data-delete="${n.id}">حذف</button></div>
    </article>`).join("");
  $("emptyState").classList.toggle("hidden", filtered.length !== 0);
}
$("noteForm").addEventListener("submit", e => {
  e.preventDefault();
  const title = $("noteTitle").value.trim();
  const text = $("noteText").value.trim();
  if(!title || !text) return;
  notes.unshift({id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), title, text, category:$("noteCategory").value, createdAt:new Date().toISOString()});
  persist(); e.target.reset();
  $("saveStatus").textContent = "تم حفظ المعلومة على جهازك بنجاح.";
});
$("notesList").addEventListener("click", e => {
  const id = e.target.dataset.delete;
  if(!id) return;
  if(confirm("متأكد تريد حذف هذه المعلومة؟")){ notes = notes.filter(n => n.id !== id); persist(); }
});
$("filter").addEventListener("input", renderNotes);

function searchMemory(question){
  const words = question.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(w => w.length > 1);
  return notes.map(n => {
    const hay = `${n.title} ${n.text} ${n.category}`.toLowerCase();
    const score = words.reduce((sum,w) => sum + (hay.includes(w) ? 1 : 0), 0);
    return {note:n,score};
  }).filter(x => x.score > 0).sort((a,b)=>b.score-a.score).slice(0,5);
}
$("askForm").addEventListener("submit", e => {
  e.preventDefault();
  const q = $("question").value.trim();
  if(!q) return;
  const results = searchMemory(q);
  $("answerCard").classList.remove("hidden");
  if(!results.length){
    $("answer").innerHTML = `<p>ما لكيت معلومة تطابق سؤالك بذاكرتك. جرّب كلمات ثانية أو احفظ المعلومة أولاً.</p>`;
  } else {
    $("answer").innerHTML = `<p class="hint">لكيت ${results.length} نتيجة قريبة من سؤالك، مرتبة حسب تطابق الكلمات:</p>` +
      results.map(({note})=>`<div class="answer-item"><h3>${escapeHtml(note.title)}</h3><p>${escapeHtml(note.text)}</p><div class="meta">${escapeHtml(note.category)} · ${new Date(note.createdAt).toLocaleDateString("ar-IQ")}</div></div>`).join("");
  }
});
$("clearAnswer").addEventListener("click", ()=>$("answerCard").classList.add("hidden"));
$("exportBtn").addEventListener("click",()=>{
  const blob = new Blob([JSON.stringify({app:"ذاكرتي AI",version:1,notes},null,2)],{type:"application/json"});
  const url = URL.createObjectURL(blob); const a=document.createElement("a");
  a.href=url;a.download="thakirati-backup.json";a.click();URL.revokeObjectURL(url);
});
$("importFile").addEventListener("change",async e=>{
  const file=e.target.files[0]; if(!file)return;
  try{
    const data=JSON.parse(await file.text());
    const incoming=Array.isArray(data)?data:data.notes;
    if(!Array.isArray(incoming))throw new Error("invalid");
    const valid=incoming.filter(n=>n && n.title && n.text).map(n=>({...n,id:n.id||String(Date.now()+Math.random()),createdAt:n.createdAt||new Date().toISOString()}));
    notes=[...valid,...notes];persist();alert(`تم استيراد ${valid.length} معلومة.`);
  }catch{alert("الملف غير صالح أو ليس نسخة من ذاكرتي AI.");}
  e.target.value="";
});
renderNotes();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
